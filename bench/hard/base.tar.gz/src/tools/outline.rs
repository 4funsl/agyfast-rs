//! quick_outline: one tree-sitter query engine for every language, plus a line
//! scanner for Markdown, unsupported extensions and parse/query failures.

use crate::core::{budget, cwd};
use rayon::prelude::*;
use serde::Deserialize;
use serde_json::Value;
use std::collections::HashMap;
use std::path::Path;

const MAX_BYTES: u64 = 2 * 1024 * 1024;
const MAX_SIG: usize = 160;

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Args {
    cwd: Option<String>,
    #[serde(default)]
    paths: Vec<String>,
    max_chars: Option<usize>,
}

pub fn run(args: Value) -> Result<String, String> {
    let args: Args = serde_json::from_value(args).map_err(|e| format!("Error: invalid arguments: {e}"))?;
    if args.paths.is_empty() || args.paths.len() > 40 {
        return Err(format!("Error: `paths` needs 1..40 entries, got {}", args.paths.len()));
    }
    let dir = cwd::resolve(args.cwd.as_deref())?;
    let parts: Vec<String> = args.paths.par_iter().map(|p| outline_file(&dir.join(p), p)).collect();
    Ok(budget::join_fair(&parts, budget::limit(args.max_chars, 1000)))
}

/// File text for outlining or slicing; `Err` is a one-line reason to show inline.
pub fn read_text(path: &Path) -> Result<String, String> {
    let meta = std::fs::metadata(path).map_err(|e| e.to_string())?;
    if !meta.is_file() {
        return Err("not a regular file".into());
    }
    if meta.len() > MAX_BYTES {
        return Err(format!("skipped: {:.1} MB is over the 2 MB limit", meta.len() as f64 / 1048576.0));
    }
    let bytes = std::fs::read(path).map_err(|e| e.to_string())?;
    if bytes[..bytes.len().min(8192)].contains(&0) {
        return Err("skipped: binary file".into());
    }
    let text = String::from_utf8_lossy(&bytes);
    Ok(text.strip_prefix('\u{feff}').unwrap_or(&text).to_string())
}

/// One `## path (N lines)` section; `shown` is the path as the caller wrote it.
pub fn outline_file(path: &Path, shown: &str) -> String {
    let src = match read_text(path) {
        Ok(s) => s,
        Err(e) if e.starts_with("skipped") => return format!("## {shown} ({e})"),
        Err(e) => return format!("## {shown}\nERROR: {e}"),
    };
    let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase();
    let rows = outline_source(&ext, &src);
    let body = if rows.is_empty() { "(no symbols detected)".to_string() } else { rows.join("\n") };
    format!("## {shown} ({} lines)\n{body}", src.lines().count())
}

fn outline_source(ext: &str, src: &str) -> Vec<String> {
    if let Some((lang, query)) = spec(ext)
        && let Some(rows) = tree_outline(&lang, query, src)
    {
        return rows;
    }
    if matches!(ext, "md" | "markdown" | "mdx") { markdown_outline(src) } else { scan_outline(src) }
}

/// The `LangSpec` table: grammar plus embedded query, each behind its feature.
fn spec(ext: &str) -> Option<(tree_sitter::Language, &'static str)> {
    match ext {
        #[cfg(feature = "lang-rust")]
        "rs" => Some((tree_sitter_rust::LANGUAGE.into(), include_str!("../../queries/rust.scm"))),
        #[cfg(feature = "lang-ts")]
        "ts" | "mts" | "cts" => Some((tree_sitter_typescript::LANGUAGE_TYPESCRIPT.into(), include_str!("../../queries/typescript.scm"))),
        #[cfg(feature = "lang-ts")]
        "tsx" => Some((tree_sitter_typescript::LANGUAGE_TSX.into(), include_str!("../../queries/typescript.scm"))),
        #[cfg(feature = "lang-ts")]
        "js" | "jsx" | "mjs" | "cjs" => Some((tree_sitter_javascript::LANGUAGE.into(), include_str!("../../queries/javascript.scm"))),
        #[cfg(feature = "lang-python")]
        "py" | "pyi" => Some((tree_sitter_python::LANGUAGE.into(), include_str!("../../queries/python.scm"))),
        #[cfg(feature = "lang-go")]
        "go" => Some((tree_sitter_go::LANGUAGE.into(), include_str!("../../queries/go.scm"))),
        #[cfg(feature = "lang-config")]
        "json" | "jsonc" => Some((tree_sitter_json::LANGUAGE.into(), include_str!("../../queries/json.scm"))),
        #[cfg(feature = "lang-config")]
        "toml" => Some((tree_sitter_toml_ng::LANGUAGE.into(), include_str!("../../queries/toml.scm"))),
        #[cfg(feature = "lang-config")]
        "yaml" | "yml" => Some((tree_sitter_yaml::LANGUAGE.into(), include_str!("../../queries/yaml.scm"))),
        _ => None,
    }
}

/// 1-based inclusive line range; a node ending at column 0 does not own that line.
fn lines_of(n: tree_sitter::Node) -> (usize, usize) {
    let (s, e) = (n.start_position(), n.end_position());
    let end = if e.column == 0 && e.row > s.row { e.row - 1 } else { e.row };
    (s.row + 1, end + 1)
}

pub fn span(s: usize, e: usize) -> String {
    if e > s { format!("L{s}-{e}") } else { format!("L{s}") }
}

/// Whitespace collapsed to single spaces, capped at `MAX_SIG` chars.
fn one_line(s: &str) -> String {
    let mut out = s.split_whitespace().collect::<Vec<_>>().join(" ").replace("( ", "(").replace(", )", ")").replace(" )", ")");
    if let Some((i, _)) = out.char_indices().nth(MAX_SIG) {
        out.truncate(i);
        out.push('…');
    }
    out
}

struct Entry {
    start: usize,
    end: usize,
    lines: (usize, usize),
    text: String,
    /// None: an item. Some(false): an import. Some(true): a test module.
    collapse: Option<bool>,
}

fn tree_outline(lang: &tree_sitter::Language, query_src: &str, src: &str) -> Option<Vec<String>> {
    tree_entries(lang, query_src, src).map(render)
}

/// Definitions as (first line, last line, one-line signature), sorted by start,
/// for files a grammar supports; empty for other files or on any failure.
pub fn symbols(path: &Path) -> Vec<(usize, usize, String)> {
    let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase();
    let Some((lang, query)) = spec(&ext) else { return Vec::new() };
    let Ok(src) = read_text(path) else { return Vec::new() };
    let entries = tree_entries(&lang, query, &src).unwrap_or_default();
    entries.into_iter().filter(|e| e.collapse.is_none()).map(|e| (e.lines.0, e.lines.1, e.text)).collect()
}

fn tree_entries(lang: &tree_sitter::Language, query_src: &str, src: &str) -> Option<Vec<Entry>> {
    use tree_sitter::StreamingIterator;
    let query = tree_sitter::Query::new(lang, query_src).ok()?;
    let mut parser = tree_sitter::Parser::new();
    parser.set_language(lang).ok()?;
    let tree = parser.parse(src, None)?;
    let idx = |name| query.capture_index_for_name(name);
    let (item_i, body_i, coll_i) = (idx("item"), idx("body"), idx("collapse"));

    // Several patterns may hit the same item; any match that found a body wins.
    let mut items: HashMap<usize, (tree_sitter::Node, Option<usize>)> = HashMap::new();
    let mut entries = Vec::new();
    let mut cursor = tree_sitter::QueryCursor::new();
    let mut matches = cursor.matches(&query, tree.root_node(), src.as_bytes());
    while let Some(m) = matches.next() {
        let of = |i| m.captures().iter().filter(move |c| Some(c.index) == i).map(|c| c.node);
        let coll: Vec<_> = of(coll_i).collect();
        if let (Some(first), Some(last)) = (coll.iter().min_by_key(|n| n.start_byte()), coll.iter().max_by_key(|n| n.end_byte())) {
            let test = coll.iter().any(|n| n.kind() == "mod_item");
            entries.push(Entry {
                start: first.start_byte(),
                end: last.end_byte(),
                lines: (lines_of(*first).0, lines_of(*last).1),
                text: if test { src[first.start_byte()..last.end_byte()].to_string() } else { String::new() },
                collapse: Some(test),
            });
        } else if let Some(item) = of(item_i).next() {
            let body = of(body_i).next().map(|b| b.start_byte());
            let slot = items.entry(item.id()).or_insert((item, None));
            slot.1 = slot.1.or(body);
        }
    }
    for (node, body) in items.into_values() {
        let text = &src[node.start_byte()..body.unwrap_or(node.end_byte())];
        let text = if body.is_some() { text } else { text.lines().next().unwrap_or("") };
        entries.push(Entry { start: node.start_byte(), end: node.end_byte(), lines: lines_of(node), text: one_line(text), collapse: None });
    }
    entries.sort_by_key(|e| (e.start, std::cmp::Reverse(e.end), e.collapse.is_none()));
    Some(entries)
}

fn render(entries: Vec<Entry>) -> Vec<String> {
    let mut rows: Vec<String> = Vec::new();
    let mut parents: Vec<usize> = Vec::new();
    let mut hidden_until = 0;
    let mut run: Option<(usize, usize, usize)> = None; // open import run: (count, first, last line)
    let flush = |run: &mut Option<(usize, usize, usize)>, rows: &mut Vec<String>| {
        if let Some((n, s, e)) = run.take() {
            rows.push(format!("{} ({n} import{})", span(s, e), if n == 1 { "" } else { "s" }));
        }
    };
    for e in entries {
        if e.start < hidden_until {
            continue;
        }
        while parents.last().is_some_and(|&end| end <= e.start) {
            parents.pop();
        }
        let (s, l) = e.lines;
        match e.collapse {
            Some(_) if !parents.is_empty() => {}
            Some(false) => match &mut run {
                Some((n, _, last)) => (*n, *last) = (*n + 1, (*last).max(l)),
                None => run = Some((1, s, l)),
            },
            Some(true) => {
                flush(&mut run, &mut rows);
                hidden_until = e.end;
                let tests = e.text.lines().map(str::trim).filter(|t| t.starts_with("#[") && t.contains("test") && !t.contains("cfg(test")).count();
                let head = e.text.lines().map(str::trim).find(|t| t.contains("mod ")).unwrap_or("mod");
                rows.push(format!("{} #[cfg(test)] {} ({tests} test{})", span(s, l), head.trim_end_matches('{').trim(), if tests == 1 { "" } else { "s" }));
            }
            None => {
                flush(&mut run, &mut rows);
                rows.push(format!("{}{} {}", "  ".repeat(parents.len()), span(s, l), e.text));
                parents.push(e.end);
            }
        }
    }
    flush(&mut run, &mut rows);
    rows
}

/// Headings outside fenced code; each spans until the next heading of the same or higher level.
fn markdown_outline(src: &str) -> Vec<String> {
    let lines: Vec<&str> = src.lines().collect();
    let mut heads = Vec::new();
    let mut fence: Option<&str> = None;
    for (i, line) in lines.iter().enumerate() {
        let t = line.trim_start();
        if let Some(f) = ["```", "~~~"].into_iter().find(|f| t.starts_with(f)) {
            fence = if fence == Some(f) { None } else { fence.or(Some(f)) };
            continue;
        }
        let level = t.bytes().take_while(|&b| b == b'#').count();
        if fence.is_none() && (1..=6).contains(&level) && t[level..].starts_with([' ', '\t']) {
            heads.push((i, level, one_line(t)));
        }
    }
    heads.iter().enumerate().map(|(k, (i, level, text))| {
        let end = heads[k + 1..].iter().find(|h| h.1 <= *level).map_or(lines.len(), |h| h.0);
        let end = (*i + 1..end).rev().find(|&j| !lines[j].trim().is_empty()).unwrap_or(*i);
        format!("{} {text}", span(i + 1, end + 1))
    }).collect()
}

const DEF_WORDS: &[&str] = &[
    "fn", "func", "fun", "function", "def", "class", "struct", "enum", "interface", "trait", "impl",
    "module", "namespace", "object", "record", "protocol", "extension", "union", "sub", "proc", "macro",
];
const MODIFIERS: &[&str] = &[
    "export", "pub", "public", "private", "protected", "internal", "static", "async", "abstract", "final",
    "override", "virtual", "inline", "extern", "default", "open", "sealed", "data", "suspend", "unsafe", "const",
];
const CONTROL: &[&str] = &["if", "for", "while", "switch", "return", "else", "catch", "new", "throw", "case", "do", "await", "yield", "delete", "typeof"];

/// Conservative guess at a definition line in an unsupported language.
fn looks_like_def(line: &str) -> bool {
    let t = line.trim();
    if t.ends_with(';') || t.ends_with(',') || t.starts_with(['/', '*', '#', '-', '<', '@', '"', '\'']) {
        return false;
    }
    let mut words = t.split_whitespace().skip_while(|w| MODIFIERS.contains(w) || w.starts_with("pub("));
    let Some(first) = words.next() else { return false };
    let first = first.trim_end_matches(|c: char| !c.is_alphanumeric() && c != '_');
    if DEF_WORDS.contains(&first) {
        return words.next().is_some_and(|w| w.starts_with(|c: char| c.is_alphabetic() || c == '_'));
    }
    // C/Java-style `Type name(args) {`: at least two words before `(` and no `=` there.
    let Some(open) = t.find('(') else { return false };
    let head = &t[..open];
    let ws: Vec<&str> = head.split_whitespace().collect();
    ws.len() >= 2
        && !head.contains(['=', '.', '!', '|', '&', '+'])
        && !CONTROL.iter().any(|c| ws.contains(c))
        && ws.last().is_some_and(|w| w.trim_start_matches('*').starts_with(|c: char| c.is_alphabetic() || c == '_'))
        && (t.ends_with('{') || t.ends_with(')'))
}

/// Definition-looking lines; each spans until the next one at the same or lower indent.
fn scan_outline(src: &str) -> Vec<String> {
    let lines: Vec<&str> = src.lines().collect();
    let indent = |l: &str| l.len() - l.trim_start().len();
    let defs: Vec<(usize, usize)> = lines.iter().enumerate().filter(|(_, l)| looks_like_def(l)).map(|(i, l)| (i, indent(l))).collect();
    let mut stack: Vec<usize> = Vec::new();
    defs.iter().enumerate().map(|(k, &(i, ind))| {
        while stack.last().is_some_and(|&p| p >= ind) {
            stack.pop();
        }
        let depth = stack.len();
        stack.push(ind);
        let next = defs[k + 1..].iter().find(|d| d.1 <= ind).map_or(lines.len(), |d| d.0);
        let end = (i + 1..next).find(|&j| !lines[j].trim().is_empty() && indent(lines[j]) < ind).unwrap_or(next);
        let end = (i + 1..end).rev().find(|&j| !lines[j].trim().is_empty()).unwrap_or(i);
        format!("{}{} {}", "  ".repeat(depth), span(i + 1, end + 1), one_line(lines[i]))
    }).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn outline(ext: &str, src: &str) -> String {
        outline_source(ext, src).join("\n")
    }

    /// Every grammar loads, every query compiles, and one known symbol lands on its lines.
    #[test]
    fn every_language_parses_and_queries_compile() {
        let cases: &[(&str, &str, &str)] = &[
            #[cfg(feature = "lang-rust")]
            ("rs", "use a::b;\nuse c::d;\n\npub struct Cache {\n  size: usize,\n}\n\nimpl Cache {\n  pub fn new(size: usize) -> Self {\n    Self { size }\n  }\n}\n", "  L9-11 pub fn new(size: usize) -> Self"),
            #[cfg(feature = "lang-ts")]
            ("ts", "import a from 'a';\nexport class Server {\n  start() {\n    return 1;\n  }\n}\nexport const createApp = (cfg: Config) => {\n  return 1;\n};\n", "L7-9 export const createApp = (cfg: Config) =>"),
            #[cfg(feature = "lang-ts")]
            ("tsx", "export function App(): JSX.Element {\n  return <div/>;\n}\n", "L1-3 export function App(): JSX.Element"),
            #[cfg(feature = "lang-ts")]
            ("js", "const x = 1;\nclass A {\n  run(a) {\n    return <b>{a}</b>;\n  }\n}\n", "  L3-5 run(a)"),
            #[cfg(feature = "lang-ts")]
            ("js", "var A = class {\n  run(a) {\n    return <b>{a}</b>;\n  }\n};\n", "L1-5 var A = class"),
            #[cfg(feature = "lang-python")]
            ("py", "import os\nclass Worker:\n    @property\n    def run(self):\n        return 42\n\nasync def helper():\n    return True\n", "  L3-5 @property def run(self):"),
            #[cfg(feature = "lang-go")]
            ("go", "package main\n\nimport (\n  \"fmt\"\n  \"os\"\n)\n\nfunc (e *Engine) Start() {\n  fmt.Println(os.Args)\n}\n", "L8-10 func (e *Engine) Start()"),
            #[cfg(feature = "lang-config")]
            ("json", "{\n    \"name\": \"demo\",\n    \"scripts\": {\n        \"test\": \"node --test\"\n    }\n}\n", "  L4 \"test\": \"node --test\""),
            #[cfg(feature = "lang-config")]
            ("toml", "[package]\nname = \"x\"\n\n[dependencies]\nserde = \"1\"\n", "  L5 serde = \"1\""),
            #[cfg(feature = "lang-config")]
            ("yaml", "on:\n  push:\n    branches: [main]\njobs:\n  build: {}\n", "  L5 build: {}"),
        ];
        for (ext, src, want) in cases {
            let (lang, q) = spec(ext).unwrap();
            if let Err(e) = tree_sitter::Query::new(&lang, q) {
                panic!("{ext} query: {e}");
            }
            let got = outline(ext, src);
            assert!(got.lines().any(|l| l == *want), "{ext}: want {want:?} in\n{got}");
        }
    }

    #[cfg(feature = "lang-rust")]
    #[test]
    fn rust_collapses_imports_and_test_modules() {
        let src = "use a;\n// c\nuse b::{c, d};\n\nfn main() {}\n\n#[cfg(test)]\nmod tests {\n    use super::*;\n    #[test]\n    fn one() {}\n    #[test]\n    fn two() {}\n}\n";
        assert_eq!(outline("rs", src), "L1-3 (2 imports)\nL5 fn main()\nL7-14 #[cfg(test)] mod tests (2 tests)");
    }

    #[cfg(feature = "lang-go")]
    #[test]
    fn go_counts_each_import_spec() {
        assert!(outline("go", "package m\nimport \"a\"\nimport (\n\"b\"\n\"c\"\n)\n").starts_with("L2-6 (3 imports)"));
    }

    #[cfg(feature = "lang-rust")]
    #[test]
    fn multibyte_signatures_keep_char_boundaries() {
        let src = format!("pub fn привіт_{}() {{}}\n", "я".repeat(300));
        let got = outline("rs", &src);
        assert!(got.starts_with("L1 pub fn привіт_") && got.ends_with('…'), "{got}");
    }

    #[test]
    fn markdown_skips_fences_and_spans_sections() {
        let src = "# Title\nIntro.\n```bash\n# not a heading\n```\n## Usage\nDetails.\n";
        assert_eq!(outline("md", src), "L1-7 # Title\nL6-7 ## Usage");
    }

    #[test]
    fn scanner_finds_c_and_java_definitions() {
        let c = "int main(int argc, char **argv) {\n  if (x) {\n  return 0;\n}\nstatic void helper(void) {\n}\n";
        assert_eq!(outline("c", c), "L1-4 int main(int argc, char **argv) {\nL5-6 static void helper(void) {");
        let java = "public class Service {\n  public int add(int a, int b) {\n    return a + b;\n  }\n}\n";
        assert_eq!(outline("java", java), "L1-5 public class Service {\n  L2-4 public int add(int a, int b) {");
    }

    #[test]
    fn binary_and_missing_files_are_one_line_notes() {
        let dir = tempfile::tempdir().unwrap();
        let bin = dir.path().join("x.bin");
        std::fs::write(&bin, [0u8, 1, 2]).unwrap();
        assert_eq!(outline_file(&bin, "x.bin"), "## x.bin (skipped: binary file)");
        assert!(outline_file(&dir.path().join("nope.rs"), "nope.rs").starts_with("## nope.rs\nERROR:"));
    }
}
